Should be Pretty Forward Implemtation.

	- Copy all folders to the Src Folder

	- the LispEvaluator Package has the java file to grade in it
		--LispEvaluator.java (Validates and Evaluates Lisp Expressions)
		--LispEvaluatorMain (Main Method of the Program, user prompts do while etc)