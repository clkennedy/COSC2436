/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author Douglas Atkinson
 */
public class FileFormatException extends Exception {
    
    public FileFormatException(String s) 
    { 
        // Call constructor of parent Exception 
        super(s); 
    } 
}

