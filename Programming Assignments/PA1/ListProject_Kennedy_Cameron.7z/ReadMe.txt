Should be Pretty Forward Implemtation.

	- Copy all folders except the "copy to base project" and add them to the Src Folder

	- add the contents of the "copy to base project" to the base directory, 
	the directory that the Src Folder resides in

	- there is a useGui folder that toggles the project to use, simple true/false
	is the only thing that can be in this file, else the program defaults to the GUI
	Version

	- the sample ToDo is also included